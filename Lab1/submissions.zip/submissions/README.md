# Lab1_Linker
please ensure g++-9.1 works

make   

./linker <INPUT-FILE>