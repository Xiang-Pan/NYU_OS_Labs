<!--
 * @Author: Xiang Pan
 * @Date: 2021-08-12 20:03:07
 * @LastEditTime: 2021-08-12 20:03:25
 * @LastEditors: Xiang Pan
 * @Description: 
 * @FilePath: /Lab4/submissions/README.md
 * xiangpan@nyu.edu
-->
please make sure that gcc-9.1 works properly.
make
./ioshed