<!--
 * @Author: Xiang Pan
 * @Date: 2021-06-15 16:55:32
 * @LastEditTime: 2021-07-13 17:06:59
 * @LastEditors: Xiang Pan
 * @Description: 
 * @FilePath: /Lab2/README.md
 * xiangpan@nyu.edu
-->
# Lab2
```
module load gcc-9.1
make
./sched --option
```